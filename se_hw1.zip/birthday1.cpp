// #define _CRT_SECURE_NO_WARNINGS
// #include <ctime>
#include <iostream>
#include <string>
#include "relations.h"
using namespace std;

// 将tm结构表示的日期转换为字符串形式
// author 吴圻茼 ChatGPT
string tmToString(const tm& date) {
    char buffer[11]; // 10个字符用于存储"YYYY-MM-DD"形式的日期，再加上字符串结束符'\0'
    strftime(buffer, sizeof(buffer), "%Y-%m-%d", &date); // 使用strftime函数格式化日期
    return string(buffer); // 将字符数组转换为string类型并返回
}

// 欢迎界面
// author 吴圻茼
void welcomeScreen() {
    cout << "欢迎使用生日聚会计划便签程序！" << endl << "编辑程序目录下的relatives.txt可以增加亲友信息" << endl; 
    readRelatives();
    cout << "" << endl << "按Enter继续..." << endl;
    cin.get();
}

// 检查输入日期的合法性
// author 吴圻茼 
bool isValidDate(int year, int month, int day) {
    // 检查年份
    if (year < 1900) {
        return false;
    }
    // 检查月份
    if (month < 1 || month > 12) {
        return false;
    }
    // 检查日期
    if (day < 1 || day > 31) {
        return false;
    }
    // 检查30天和31天的月份
    if ((month == 4 || month == 6 || month == 9 || month == 11) && day > 30) {
        return false;
    }
    // 检查2月份的日期
    if (month == 2) {
        // 如果是闰年，最多29天
        if ((year % 4 == 0 && year % 100 != 0) || (year % 400 == 0)) {
            if (day > 29) {
                return false;
            }
        }
        else {
            if (day > 28) {
                return false;
            }
        }
    }
    return true;
}

// 获取输入的日期
// author 吴圻茼
tm getDay(string disc = "日期") {
    tm d = {};
    cout << "请输入" << disc << "（年 月 日）： ";
    while (1)
    {
        cin >> d.tm_year >> d.tm_mon >> d.tm_mday;
        // 检查日期合法性
        if (isValidDate(d.tm_year, d.tm_mon, d.tm_mday)) {
            d.tm_year -= 1900;
            d.tm_mon -= 1;
            break;
        }
        else {
            cout << "输入的日期不合法，请重新输入！" << endl;
        }
    }
    return d;
}

// 计算下次日期距离今天的天数
// author 顾田 ChatGPT
int calcDaystoBirthday(tm today, tm nextBirthday) {
    // 将tm结构转换为time_t结构
    time_t today_time = mktime(&today);
    time_t birthday_time = mktime(&nextBirthday);
    // 计算时间差（秒数）
    double t = difftime(birthday_time, today_time);
    // 将时间差从秒数转换为天数
    int days = t / (60 * 60 * 24);
    // 如果时间差为负数，表示生日已经过去，所以加上365天
    if (days < 0) {
        days += 365;
    }
    return days;
}

// 计算计划日期
// author 顾田 
tm calcPlannedDate(tm nextBirthday, int daysForward) {
    // 将下次生日日期转换为time_t结构
    time_t nextBirthday_time = mktime(&nextBirthday);
    // 计算提前n天的秒数
    int forward_seconds = daysForward * 24 * 60 * 60;
    // 计算计划日期的time_t值
    time_t plannedDate_time = nextBirthday_time - forward_seconds;
    // 将计划日期的time_t值转换回tm结构
    tm plannedDate = *localtime(&plannedDate_time);
    return plannedDate;
}

// 计算除去工作日后的计划日期
// author 顾田
tm calcFinalDate(tm plannedDate) {
    // 判断是否为5月1-3日，10月1-7日
    if ((plannedDate.tm_mon == 4 && plannedDate.tm_mday < 4)||(plannedDate.tm_mon == 9 && plannedDate.tm_mday < 8)) {
        cout << "这一天是节假日，就在这一天举办聚会。" << endl;
    }
    // 判断是否是工作日
    else if (plannedDate.tm_wday != 0 && plannedDate.tm_wday != 6) {
        int daysForward = 0;
        if (plannedDate.tm_wday < 3) {
            // 如果计划日期是周一、周二，则最近的周六为前一个周六
            daysForward = 5 - plannedDate.tm_wday;
        }
        else {
            // 如果计划日期是周三、周四、周五，则最近的周六为后一个周六
            daysForward = plannedDate.tm_wday - 6;
        }
        // 减去或加上时间，调整到最近的周六。
        time_t plannedDate_time = mktime(&plannedDate);
        int forward_seconds = daysForward * 24 * 60 * 60;
        plannedDate_time -= forward_seconds;
        plannedDate = *localtime(&plannedDate_time);

        string s = tmToString(plannedDate);
        cout << "这一天是工作日，更改到" << s << "聚会" << endl;
    }
    else {
        cout << "这一天是休息日，就在这一天举办聚会。" << endl;
    }
    return plannedDate;
}

// 实现最终结果输出
// author 顾田
void outputResult(vector<string> ss) {
    int count = ss.size();
    cout << "***************[最终结果]***************" << endl;
    cout << "姓名 \t关系 \t生日日期 \t计划日期" << endl;
    for (int j = 0; j < count; j = j + 4) {
        cout << ss[j] << "\t" << ss[j+1] << "\t" << ss[j+2] << "\t" << ss[j+3] << "\t" << endl;
    }
}

// 主函数
// author 吴圻茼 顾田
int main() {
    char usrInput;
    // 显示欢迎界面
    welcomeScreen();
    vector<string> results;
    int count = 0;

    while (1) {
        // 展示所有的亲友
        showRelatives();

        unsigned index;
        cout << "请选择你要为哪一位亲友制定生日计划(输入ta的索引)：" << endl;
        cin >> index;
        while(index>=Relatives.size()) {
            cout << "索引不存在，请重新输入" <<endl;
            cin >> index;
        }

        cout << "您选择的亲友信息：" << endl;
        showOneRelative(index);

        // 选定的亲友的信息
        tm dateBirthday = Relatives[index].Birthday;
        string name = Relatives[index].Name;
        string relation = Relatives[index].Relation;

        // 今天的日期
        tm dateToday = getDay("今天日期");

        // 设置下次生日的年份为今年，如果生日已过，就设置为明年
        tm dateNextBirthday = dateBirthday;
        dateNextBirthday.tm_year = dateToday.tm_year;
        if (dateToday.tm_mon > dateNextBirthday.tm_mon || (dateToday.tm_mon == dateNextBirthday.tm_mon && dateToday.tm_mday > dateNextBirthday.tm_mday)) {
            dateNextBirthday.tm_year += 1;
        }
        if (!isValidDate(dateNextBirthday.tm_year + 1900, dateNextBirthday.tm_mon + 1, dateNextBirthday.tm_mday)) {
            dateNextBirthday.tm_mday -= 1; // 考虑闰年2月29日的问题
        }

        // 计算距离下次生日的天数
        int daystoBirthday = calcDaystoBirthday(dateToday, dateNextBirthday);
        // 显示下次生日日期、下次生日距离今天的天数。
        string s = tmToString(dateNextBirthday);
        cout << "下次生日日期：" << s << endl << "距离今天天数：" << daystoBirthday << endl;

        // 提示用户输入希望提前“多少”天做聚会计划
        int daysForward = 0;
        cout << "希望提前多少天做聚会计划？" << endl;
        cin >> daysForward;

        // 程序显示下次生日前 n 天的日期作为计划日期
        tm plannedDay = calcPlannedDate(dateNextBirthday, daysForward);
        string s1 = tmToString(plannedDay);
        cout << "计划日期：" << s1 << endl;

        // 如果这一天是工作日，则提示用户，并改为最近的一个周六为计划日期
        tm finalDay = calcFinalDate(plannedDay);
       

        // 用户确认是否重新计算
        cout << "是否重新计算日期？或为其他亲友设定日期？ 是 y / 否 n / 为其他亲友制订 k ：";
        cin >> usrInput;
        if (usrInput != 'Y' && usrInput != 'y') {
            // 保存这个亲友的生日计划
            count++;
            results.push_back(name);  // 姓名
            results.push_back(relation); // 关系
            results.push_back(s); // 生日日期
            results.push_back(tmToString(finalDay)); // 最终计划日期
        }
        if (usrInput == 'n' || usrInput == 'N') {
            // 最终打印结果
            outputResult(results);
            system("pause");
            break;
        }
    }
    return 0;
}