// author 顾田
// 录入并保存一些亲友的信息
#include <ctime>
#include <vector>
#include <fstream>
#include <sstream>
#include <iostream>
using namespace std;

// 亲友成员的结构体
struct Relative {
    char Name[20];
    char Relation[20];
    tm Birthday;
};

// 保存所有亲友的信息
vector<Relative> Relatives;

// 从txt文件中逐行读入每一位亲友， 文件内的格式为：
// 姓名 关系 生日年 生日月 生日日
// 使用了ChatGPT
void readRelatives(){
    ifstream infile("relatives.txt");
    if (!infile) {
        cout << "Error opening file for reading." << endl;
        return;
    }

    string line;
    while (getline(infile, line)) {
        istringstream iss(line);
        Relative relative = {};
        iss >> relative.Name >> relative.Relation >> relative.Birthday.tm_year >> relative.Birthday.tm_mon >> relative.Birthday.tm_mday;
        relative.Birthday.tm_year -= 1900;
        relative.Birthday.tm_mon -= 1;
        Relatives.push_back(relative);
    }
    infile.close();
}

// 将所有亲友的信息写回txt
// 使用了ChatGPT
void writeRelatives(){
    ofstream outfile("relatives.txt");
    if (!outfile) {
        cout << "Error opening file for writing." << endl;
        return;
    }

    for (const auto& relative : Relatives) {
        outfile << relative.Name << " " << relative.Relation << " " << relative.Birthday.tm_year << " " << relative.Birthday.tm_mon << " " << relative.Birthday.tm_mday << endl;
    }
    outfile.close();
}

// 使用索引展示一位亲友
void showOneRelative(int i) {
    Relative relative = Relatives[i];
    cout << "[" << i << "]\t";
    cout << relative.Name << "\t" << relative.Relation << "\t" << relative.Birthday.tm_year+1900 << "-" << relative.Birthday.tm_mon+1 << "-" << relative.Birthday.tm_mday << endl;
}

// 展示所有亲友的信息
// 使用了ChatGPT
void showRelatives(){
    cout << "所有亲友的信息：" << endl <<
    "索引\t姓名\t关系\t生日\t" << endl;
    
    for (int index = 0; index < Relatives.size(); index++) {
        showOneRelative(index);
    }
}